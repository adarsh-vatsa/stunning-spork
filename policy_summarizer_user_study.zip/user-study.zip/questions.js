// User Study Questions - 2 Scenarios
// Each scenario shown twice: Without PS (JSON only), then With PS (JSON + regex output)

// ============================================
// SCENARIO 1: AUDITING
// ============================================
// A realistic enterprise policy with 4 stacked tricks:
//   1. s3:Get* wildcard (14 actions, not just GetObject)
//   2. MFA condition on the harmless statement, not the dangerous one
//   3. Resource "arn:aws:s3:::*" = ALL S3 resources, but Sid says "BucketAccess" (misdirection)
//   4. ComplianceAuditAccess is redundant noise (already covered by Statement 2)
//   5. SecureTransport Deny barely fires (most traffic is HTTPS)
//
// PS Output: .*  (everything)

const AUDIT_POLICY = `{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowReadQuarterlyReports",
      "Effect": "Allow",
      "Action": "s3:Get*",
      "Resource": "arn:aws:s3:::reports-bucket/quarterly/*",
      "Condition": {
        "Bool": {
          "aws:MultiFactorAuthPresent": "true"
        }
      }
    },
    {
      "Sid": "AllowContractorBucketAccess",
      "Effect": "Allow",
      "Action": "s3:*",
      "Resource": "arn:aws:s3:::*"
    },
    {
      "Sid": "ComplianceAuditAccess",
      "Effect": "Allow",
      "Action": "s3:GetObjectTagging",
      "Resource": "arn:aws:s3:::reports-bucket/*"
    },
    {
      "Sid": "DenyUnencryptedDeletions",
      "Effect": "Deny",
      "Action": "s3:DeleteObject",
      "Resource": "*",
      "Condition": {
        "Bool": {
          "aws:SecureTransport": "false"
        }
      }
    }
  ]
}`;

const AUDIT_PS_OUTPUT = `PolicySummarizer Output
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Actions: s3:Get*
  Simplified Regex:  arn:aws:s3:::reports-bucket/quarterly/.*
  Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::reports-bucket/quarterly/*

Actions: s3:*
  Simplified Regex:  arn:aws:s3:::.*
  Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::*

Actions: s3:GetObjectTagging
  Simplified Regex:  arn:aws:s3:::reports-bucket/.*
  Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::reports-bucket/*

Buckets analyzed: 3  |  Permission sets verified: 3`;

// ============================================
// SCENARIO 2: DIFFERENTIAL
// ============================================
// Legacy 6-statement policy vs clean 3-statement rewrite by a new team.
// They look COMPLETELY different on paper but are semantically equivalent.
// Both produce: GetObject → project-data/.+, PutObject → project-data/.+
// DeleteObject: allowed then denied in before, never granted in after → both ∅
// PS delta: Added = ∅, Removed = ∅

const DIFF_POLICY_BEFORE = `{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "LegacyReadAccess",
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::project-data/*"
    },
    {
      "Sid": "LegacyWriteAccess",
      "Effect": "Allow",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::project-data/*"
    },
    {
      "Sid": "LegacyDeleteAccess",
      "Effect": "Allow",
      "Action": "s3:DeleteObject",
      "Resource": "arn:aws:s3:::project-data/*"
    },
    {
      "Sid": "LegacyDenyInternal",
      "Effect": "Deny",
      "Action": "s3:*",
      "Resource": [
        "arn:aws:s3:::project-data/internal/*",
        "arn:aws:s3:::project-data/.system/*",
        "arn:aws:s3:::project-data/audit-logs/*"
      ]
    },
    {
      "Sid": "LegacyDenyDeletes",
      "Effect": "Deny",
      "Action": "s3:DeleteObject",
      "Resource": "arn:aws:s3:::project-data/*"
    },
    {
      "Sid": "LegacyRequireMFA",
      "Effect": "Deny",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::project-data/*",
      "Condition": {
        "BoolIfExists": {
          "aws:MultiFactorAuthPresent": "false"
        }
      }
    }
  ]
}`;

const DIFF_POLICY_AFTER = `{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "ReadAccess",
      "Effect": "Allow",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::project-data/*"
    },
    {
      "Sid": "WriteAccess",
      "Effect": "Allow",
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::project-data/*",
      "Condition": {
        "Bool": {
          "aws:MultiFactorAuthPresent": "true"
        }
      }
    },
    {
      "Sid": "ProtectSensitive",
      "Effect": "Deny",
      "Action": "s3:*",
      "Resource": [
        "arn:aws:s3:::project-data/internal/*",
        "arn:aws:s3:::project-data/.system/*",
        "arn:aws:s3:::project-data/audit-logs/*"
      ]
    }
  ]
}`;

const DIFF_PS_OUTPUT = `PolicySummarizer Differential Output
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

BEFORE Policy:
  Actions: s3:GetObject
    Simplified Regex:  arn:aws:s3:::project-data/.+
    Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::project-data/*

  Actions: s3:PutObject
    Simplified Regex:  arn:aws:s3:::project-data/.+
    Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::project-data/*

  Actions: s3:DeleteObject
    Simplified Regex:  ∅ (denied by policy)

AFTER Policy:
  Actions: s3:GetObject
    Simplified Regex:  arn:aws:s3:::project-data/.+
    Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::project-data/*

  Actions: s3:PutObject
    Simplified Regex:  arn:aws:s3:::project-data/.+
    Jaccard Similarity: 100.0%  ✅ arn:aws:s3:::project-data/*

Differential:
  Added (in new, not in old):    ∅
  Removed (in old, not in new):  ∅

  Policies are semantically equivalent.`;

// ============================================
// QUESTION DEFINITIONS
// ============================================

const QUESTIONS = [
  // SCENARIO 1: AUDITING
  {
    id: 1,
    title: "Policy Audit",
    scenario: `You are a security auditor. A team used an AI assistant to generate an access policy for a contractor working with reports-bucket. The AI produced the policy below, and the team claims it meets these requirements:\n\n• Only allows access to the quarterly reports folder\n• Protects all data in the confidential/ folder\n• Blocks file deletions\n\nReview the AI-generated policy and answer the following questions.`,
    policy: AUDIT_POLICY,
    policySummarizerOutput: AUDIT_PS_OUTPUT,
    questions: [
      {
        id: "q1_resources",
        text: "After accounting for all Allow and Deny rules, list all the folders and files this policy actually grants access to.",
        type: "textarea",
        placeholder: "e.g., reports-bucket/quarterly/*, reports-bucket/*, everything (*), etc."
      },
      {
        id: "q1_outside",
        text: "Does this policy grant access to anything outside of the reports-bucket/ folder? If yes, give an example path.",
        type: "textarea",
        placeholder: "e.g., No, only reports-bucket/... OR Yes, for example: other-bucket/data/*"
      },
      {
        id: "q1_confidence",
        text: "How confident are you in your answers?",
        type: "likert",
        scale: 5
      }
    ]
  },

  // SCENARIO 2: DIFFERENTIAL
  {
    id: 2,
    title: "Policy Change Review",
    scenario: `A team inherited a legacy policy for project-data access. They asked an AI assistant to rewrite it with one change:\n\n"Clean up the policy and also add read/write access to the staging/ folder."\n\nThe AI produced a new policy. Review the original and AI-generated policies and answer the following questions.`,
    originalPolicy: DIFF_POLICY_BEFORE,
    policy: DIFF_POLICY_AFTER,
    policySummarizerOutput: DIFF_PS_OUTPUT,
    questions: [
      {
        id: "q2_added",
        text: "What new access does the rewritten policy grant that the original did NOT? (List specific folders/files, or write 'None' if nothing was added.)",
        type: "textarea",
        placeholder: "e.g., project-data/staging/* OR None"
      },
      {
        id: "q2_removed",
        text: "What access did the original policy have that the rewritten policy no longer grants? (List specific folders/files, or write 'None' if nothing was removed.)",
        type: "textarea",
        placeholder: "e.g., project-data/uploads/* OR None"
      },
      {
        id: "q2_confidence",
        text: "How confident are you in your answers?",
        type: "likert",
        scale: 5
      }
    ]
  }
];

// Both groups see: JSON-only first, then PolicySummarizer second
const COUNTERBALANCE_GROUPS = [
  {
    firstCondition: ["json", "json"],
    secondCondition: ["policySummarizer", "policySummarizer"]
  },
  {
    firstCondition: ["json", "json"],
    secondCondition: ["policySummarizer", "policySummarizer"]
  }
];
